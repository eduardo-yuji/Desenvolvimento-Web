<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "trab2";

// Create connection
 
$strcon = mysqli_connect($servername, $username, $password, $dbname, 3307) or die('Erro ao conectar ao banco de dados');
  
?>      